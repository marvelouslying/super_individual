export { default } from "./ArticlesPreview";
