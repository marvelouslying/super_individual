export { default } from "./FavButton";
